source("/home/user/D:/HDE/Helder1/Trabalhos/Production/Pain/est/karol.R")
source("/home/user/D:/HDE/Helder1/Trabalhos/Production/Pain/est/karol_sib.R")
source("/home/user/D:/HDE/Helder1/Trabalhos/Production/Pain/est/karol_sib_HR.R")
source("/home/user/D:/HDE/Helder1/Trabalhos/Production/Pain/est/karol_sib_PS.R")
source("/home/user/D:/HDE/Helder1/Trabalhos/Production/Pain/est/karol_vap.R")

